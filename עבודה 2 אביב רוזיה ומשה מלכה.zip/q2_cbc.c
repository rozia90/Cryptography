#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void  block_encryption(int *plaintext, int *K);
void copyarr(int *from, int *to, int n);
void initial_permutation(int *out);
int afterexbinary(int num);
void shiftkey(int *k);
void invers_permutation(int *p);
int extention(int *block);
void set_key(int *p);
void ChartoBinary(char in[], int *out);

int  bitsarry[16] = { 0 }, keybits[12] = { 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0 }, IV[16] = { 0 };
const int DesSbox[4][16] = {
	{ 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7 },
	{ 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8 },
	{ 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0 },
	{ 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13 },
};

void main()
{
	int i, j = 0, savekey[12] = { 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0 };
	char input[9], temp[2];

	printf("please enter 8 letters: ");
	scanf("%s", &input);
	printf("the key is: ");
	for (i = 0; i < 12; i++)
		printf("%d ", keybits[i]);
	printf("\nafter encryption:");
	for (i = 0; i < 8; i = i + 2)
	{

		temp[0] = input[i];
		temp[1] = input[i + 1];
		ChartoBinary(temp, bitsarry);
		for (j = 0; j < 16; j++)
			bitsarry[j] = bitsarry[j] ^ IV[j];
		block_encryption(bitsarry, keybits);
		for (j = 0; j < 16; j++)
			IV[j] = bitsarry[j];
		for (j = 0; j < 16; j++)
			bitsarry[j] = 0;
		for (j = 0; j < 12; j++)
			keybits[j] = savekey[j];
	}
	getch();
}

void ChartoBinary(char in[], int *out)
{
	int first, second, i = 7;
	first = in[0] - 'a';
	second = in[1] - 'a';
	while (first)
	{
		out[i] = first & 1;
		first = first >> 1;
		i--;
	}
	i = 15;
	while (second)
	{
		out[i] = second & 1;
		second = second >> 1;
		i--;
	}
}

void  initial_permutation(int *out)
{
	int i, j, temp[16],
		ip[4][4] = { { 8, 13, 4, 9 },{ 16, 5, 12, 1 },{ 7, 14, 3, 10 },{ 15, 6, 11, 2 } };
	for (i = 0; i < 4; i++)
		for (j = 0; j < 4; j++)
			temp[(i * 4) + j] = out[ip[i][j] - 1];
	for (i = 0; i < 16; i++)
		out[i] = temp[i];
}

int extention(int *block)
{
	int *newblock, i;
	newblock = (int*)malloc(sizeof(int) * 12);
	if (newblock == NULL)
	{
		printf("No space exit memory");
		exit(1);
	}

	for (i = 0; i < 8; i++)
		newblock[i + 2] = block[i];

	newblock[0] = block[7];
	newblock[1] = block[1];
	newblock[10] = block[0];
	newblock[11] = block[6];
	return newblock;
}

int afterexbinary(int num)
{
	int *out, i;
	out = (char*)malloc(sizeof(int) * 4);
	if (out == NULL)
	{
		printf("No space exit memory");
		exit(1);
	}
	for (i = 3; i >= 0; i--)
	{
		out[i] = (num & 1);
		num = num >> 1;
	}
	return out;
}

void shiftkey(int *k)
{
	int n = k[0], i;
	for (i = 1; i < 12; i++)
		k[i - 1] = k[i];
	k[11] = n;
}
void set_key(int *p)
{
	int n = p[11], i;
	for (i = 11; i>0; i--)
		p[i] = p[i - 1];
	p[0] = n;

}

void invers_permutation(int *p)
{
	int temparr[16], i, j,
		invers[4][4] = { { 8, 16, 11, 3 },{ 6, 14, 9, 1 },{ 4, 12, 15, 7 },{ 2, 10, 13, 5 } };
	for (i = 0; i < 4; i++)
		for (j = 0; j < 4; j++)
			temparr[(i * 4) + j] = p[invers[i][j] - 1];
	for (i = 0; i < 16; i++)
		p[i] = temparr[i];

}

void copyarr(int *from, int *to, int n)
{
	int i = 0;
	for (; i < n; i++)
		to[i] = from[i];
}

void  block_encryption(int *plaintext, int *K)
{
	int ORptr[8], OLptr[8], NRptr[8], NLptr[8], i, *ae, j, num1 = 0, num2 = 0, *binary;

	char c;
	initial_permutation(plaintext);
	for (i = 0; i < 8; i++)
	{
		OLptr[i] = plaintext[i];
		ORptr[i] = plaintext[i + 8];
	}
	for (i = 0; i < 4; i++)
	{
		copyarr(ORptr, NLptr, 8);

		ae = extention(ORptr);
		for (j = 0; j < 12; j++)
			ae[j] = ae[j] ^ K[j];
		num1 = DesSbox[ae[0] * 2 + ae[5]][ae[4] + ae[3] * 2 + ae[2] * 4 + ae[1] * 8];
		num2 = DesSbox[ae[6] * 2 + ae[11]][ae[10] + ae[9] * 2 + ae[8] * 4 + ae[7] * 8];
		free(ae);
		ae == (int*)malloc(sizeof(int) * 8);
		if (ae == NULL)
		{
			printf("No space exit memory");
			exit(1);
		}
		binary = afterexbinary(num1);
		for (j = 0; j < 4; j++)
			ae[j] = binary[j];
		free(binary);
		binary = afterexbinary(num2);
		for (j = 0; j < 4; j++)
			ae[j + 4] = binary[j];
		free(binary);

		for (j = 0; j < 8; j++)
			NRptr[j] = OLptr[j] ^ ae[j];
		free(ae);
		shiftkey(K);
		copyarr(NLptr, OLptr, 8);
		copyarr(NRptr, ORptr, 8);
	}
	for (i = 0; i < 8; i++)
	{
		plaintext[i] = NRptr[i];
		plaintext[i + 8] = NLptr[i];
	}
	j = 0;
	invers_permutation(plaintext);
	for (i = 7; i >= 0; i--)
		j = j + (bitsarry[i] * pow(2.0, (7 - i)));
	j = j % 26;
	c = j + 'a';
	printf("%c ", c);
	j = 0;
	for (i = 15; i >= 8; i--)
		j = j + (bitsarry[i] * pow(2, 15 - i));
	j = j % 26;
	c = j + 'a';
	printf(" %c ", c);
}