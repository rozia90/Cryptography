#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <conio.h>
#include <string.h>


void keyToMatrix(int A3[][2], int A2[][2], char* tempKey);
void multipuleKey(int A[][2]);
void addKey(int A[][2]);
void finalMatrix(int A3[][2], int A2[][2], int finalKey[][2]);
void door_encryption(char* ptext, int key[][2]);

int main() {
	int A3[2][2], A2[2][2], finalKey[2][2];
	char text[21], tempKey[5];
	int length,odd=0;
	//create the key matrixs
	do {
		printf("Enter 4 letters key: ");
		scanf("%s", &tempKey);
	} while (strlen(tempKey) != 4);
	keyToMatrix(A3, A2, tempKey);
	//get the text from the user
	do {
		printf("Enter a plain text to encrypt length=<2-20>: ");
		scanf("%s", &text);
	} while (strlen(text) > 20 || strlen(text) < 2);
		length = (int)strlen(text);
		if ((length % 2) == 1){
			text[length] = 'a';
			text[length + 1] = '\0';
			odd = 1;
		}

		multipuleKey(A3);					//doing A^3
		addKey(A2);							//doing 2*A
		finalMatrix(A3, A2,finalKey);		//doing A^3+2A
		door_encryption(text, finalKey);	//encrypts the text
		if (odd) {
			text[length] = '\0';
		}
		printf("The encrypt text is: %s", text);
		_getch();
	}
	//this function copy the given key to matrixes for a later use
	void keyToMatrix(int A3[][2],int A2[][2], char* tempKey) {
		int i, j,k=0;

		for (i = 0; i < 2; i++)
			for (j = 0; j < 2; j++) {
				A3[i][j] = A2[i][j] = tempKey[k] - 'a';
				k++;
			}
	}
	//doing A^3
	void multipuleKey(int A[][2]) {
		int i, j, k;
		int temp[2][2];

		temp[0][0] = (A[0][0] * A[0][0] + A[0][1] * A[1][0]) % 26;
		temp[0][1] = (A[0][0] * A[0][1] + A[0][1] * A[1][1]) % 26;
		temp[1][0] = (A[1][0] * A[0][0] + A[1][1] * A[1][0]) % 26;
		temp[1][1] = (A[1][0] * A[0][1] + A[1][1] * A[1][1]) % 26;

		A[0][0] = (temp[0][0] * A[0][0] + temp[0][1] * A[1][0]) % 26;
		A[0][1] = (temp[0][0] * A[0][1] + temp[0][1] * A[1][1]) % 26;
		A[1][0] = (temp[1][0] * A[0][0] + temp[1][1] * A[1][0]) % 26;
		A[1][1] = (temp[1][0] * A[0][1] + temp[1][1] * A[1][1]) % 26;
	}
	//doing 2*A
	void addKey(int A[][2]) {
		A[0][0] = (A[0][0] + A[0][0]) % 26;
		A[0][1] = (A[0][1] + A[0][1]) % 26;
		A[1][0] = (A[1][0] + A[1][0]) % 26;
		A[1][1] = (A[1][1] + A[1][1]) % 26;
	}
	//doing A^3+2A
	void finalMatrix(int A3[][2], int A2[][2],int finalKey[][2]) {
		finalKey[0][0] = (A2[0][0] + A3[0][0]) % 26;
		finalKey[0][1] = (A2[0][1] + A3[0][1]) % 26;
		finalKey[1][0] = (A2[1][0] + A3[1][0]) % 26;
		finalKey[1][1] = (A2[1][1] + A3[1][1]) % 26;
	}
	//this function encrypt a given text using the key matrix
	void door_encryption(char* ptext, int key[][2]) {
		int n = strlen(ptext), i;

		for (i = 0; i < n; i += 2){
			ptext[i] = ((ptext[i] - 'a')* key[0][0] + (ptext[i + 1] - 'a')* key[1][0]) % 26 + 'a';
			ptext[i + 1] = ((ptext[i] - 'a')* key[0][1] + (ptext[i + 1] - 'a')* key[1][1]) % 26 + 'a';
		}
	}